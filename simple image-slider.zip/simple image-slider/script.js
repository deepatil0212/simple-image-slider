// Array of image URLs
const images = [
    "https://wallpaperaccess.com/full/2416021.jpg",
    "https://images.pexels.com/photos/459225/pexels-photo-459225.jpeg?cs=srgb&dl=daylight-environment-forest-459225.jpg&fm=jpg",
    "https://t4.ftcdn.net/jpg/07/08/47/75/360_F_708477508_DNkzRIsNFgibgCJ6KoTgJjjRZNJD4mb4.jpg",
    "https://wallpaperset.com/w/full/0/d/5/183330.jpg",
    "http://wallup.net/wp-content/uploads/2016/03/10/319576-photography-landscape-nature-water-grass-trees-plants-sunrise-lake.jpg"
];

let currentIndex = 0;

// Function to change image
function updateImage() {
    document.getElementById("slider").src = images[currentIndex];
}

// Show next image
function nextImage() {
    currentIndex = (currentIndex + 1) % images.length; // Loop back to first image
    updateImage();
}

// Show previous image
function prevImage() {
    currentIndex = (currentIndex - 1 + images.length) % images.length; // Loop to last image
    updateImage();
}

// Load the first image on page load
window.onload = updateImage;
